import type { Metadata } from 'next';
import { Inter } from 'next/font/google';
import './globals.css';
// import { AuthProvider } from '@/contexts/AuthContext'

const inter = Inter({ subsets: ['latin'] });

export const metadata: Metadata = {
  title: 'Lilly Digital Wallet',
  description: 'Send vouchers and copay cards to mobile numbers',
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en">
      <body className={`${inter.className} bg-gray-100 text-black`}>
        {/* <AuthProvider> */}
        {/* ✅ Header */}
       <header className="flex items-center justify-between bg-black p-3 relative shadow">
  <div className="flex items-center space-x-4">
    {/* Replace image logo with text logo */}
    <h1 className="text-red-600 text-3xl font-[cursive] select-none cursor-default">
      Lilly
    </h1>
  </div>

  <div className="relative group cursor-pointer">
    {/* profile icon */}
  </div>
</header>


        {/* ✅ Main content */}
        <main className="min-h-screen p-4">{children}</main>

        {/* ✅ Footer */}
        <footer className="mt-6 bg-[#003366] p-4 text-center text-sm text-white">
          <a href="#" className="mx-3 hover:underline">
            Contact us
          </a>
          <a href="#" className="mx-3 hover:underline">
            Terms of Use
          </a>
          <a href="#" className="mx-3 hover:underline">
            Privacy Statement
          </a>
        </footer>

        {/* </AuthProvider> */}
      </body>
    </html>
  );
}
